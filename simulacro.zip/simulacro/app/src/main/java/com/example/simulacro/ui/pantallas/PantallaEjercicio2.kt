package com.example.simulacro.ui.pantallas

import com.example.simulacro.ui.UsuarioUIState

fun PantallaEjercicio2(
    appUIState: UsuarioUIState,
) {

}