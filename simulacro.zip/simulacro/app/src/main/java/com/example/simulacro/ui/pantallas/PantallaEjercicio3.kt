package com.example.simulacro.ui.pantallas

import com.example.simulacro.ui.UsuarioUIState

fun PantallaEjercicio3(
    appUIState: UsuarioUIState,
) {

}